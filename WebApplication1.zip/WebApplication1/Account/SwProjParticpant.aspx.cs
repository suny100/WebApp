﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;

namespace WebApplication1.Account
{
    public partial class SwProjParticpant : System.Web.UI.Page
    {
        
        protected void Page_Load(object sender, EventArgs e)
        {
            //DropDownList ddl = (DropDownList)ListView1.FindControl("ProjectIDTextBox1");
            //RemoveDuplicateItems(ddl);
        }

        protected void ProjectIDTextBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string strConnection = null;
                        strConnection = "Data Source=DESKTOP-HJRRBDG;Initial Catalog=TDC;Integrated Security=True";
            
            DropDownList ddlListFind = (DropDownList)sender;
            ListViewItem item1 = (ListViewItem)ddlListFind.NamingContainer;

            DropDownList getDDLList = (DropDownList)item1.FindControl("ProjectIDTextBox1");

            DropDownList schoolbox = (DropDownList)item1.FindControl("SchoolIDTextBox");

            int ProjectID = Convert.ToInt32(getDDLList.SelectedValue);
SqlConnection con = new SqlConnection(strConnection);
con.Open();
SqlCommand cmd = new SqlCommand("select distinct  * from SupervisionSoftware inner join Schools On SupervisionSoftware.SchoolID = Schools.SchoolID where SupervisionSoftware.ProjectID=" + ProjectID, con);
SqlDataAdapter da = new SqlDataAdapter(cmd);
DataSet ds = new DataSet();
da.Fill(ds);

schoolbox.DataSource = ds;
schoolbox.DataTextField = "Name";
schoolbox.DataValueField = "SchoolID";
schoolbox.DataBind();
//schoolbox.Items.Insert(0, new ListItem("--Select--", "0"));

con.Close();


            //string message = "Simple MessageBox";
            //string title = "Title";
            ////MessageBox.Show(message, title);
            //ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('" + message + "');", true);

            //if (Convert.ToInt32(getDDLList.SelectedItem.Value) == -1)
            //{
            //    ScriptManager.RegisterStartupScript(this, this.GetType(), "popup", "alert('Lütfen Bir Seçim Yapınız');", true);
            //}
            //else
            //{
            //    lblMessage.Text = ddlListFind.SelectedItem.Value;
            //}
        }

        //protected void SchoolIDTextBox_DataBinding(object sender, EventArgs e)
        //{
        //    DropDownList ddlListFind = (DropDownList)sender;
        //    ListViewItem item1 = (ListViewItem)ddlListFind.NamingContainer;
        //    DropDownList schoolbox = (DropDownList)item1.FindControl("SchoolIDTextBox");

        //    int ProjectID = Convert.ToInt32(schoolbox.SelectedValue);
        //    string strConnection = null;
        //    strConnection = "Data Source=DESKTOP-HJRRBDG;Initial Catalog=TDC;Integrated Security=True";
        //    SqlConnection con = new SqlConnection(strConnection);
        //    con.Open();
        //    SqlCommand cmd = new SqlCommand("INSERT INTO [SWprjectPart] ([SchoolID]) VALUES" +ProjectID, con);
        //    SqlDataAdapter da = new SqlDataAdapter(cmd);
        //   //DataSet ds = new DataSet();
        //   ////da.Fill(ds);

        //   //schoolbox.DataSource = ds;
        //   //schoolbox.DataTextField = "Name";
        //   //schoolbox.DataValueField = "SchoolID";
        //   //schoolbox.DataBind();
        //    //schoolbox.Items.Insert(0, new ListItem("--Select--", "0"));

        //    con.Close();
        //}

        ////public void RemoveDuplicateItems(DropDownList ddl)
        ////{
        ////    for (int i = 0; i < ddl.Items.Count; i++)
        ////    {
        ////        ddl.SelectedIndex = i;
        ////        string str = ddl.SelectedItem.ToString();
        ////        for (int counter = i + 1; counter < ddl.Items.Count; counter++)
        ////        {
        ////            ddl.SelectedIndex = counter;
        ////            string compareStr = ddl.SelectedItem.ToString();
        ////            if (str == compareStr)
        ////            {
        ////                ddl.Items.RemoveAt(counter);
        ////                counter = counter - 1;
        ////            }
        ////        }
        ////    }
        ////}
        ////protected void ListView1_OnItemInserting(object sender, EventArgs e)
        ////{
        ////    string sv = ((DropDownList)ListView1.InsertItem.FindControl("SchoolIDTextBox")).SelectedValue;
        ////    //int ProjectID = Convert.ToInt32(sv);
        //    SqlDataSource2.InsertParameters.Add("SchoolID", sv);

        //}
    }
}