﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;

namespace WebApplication1.Account
{
    public partial class UserLogin : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection("Data Source=TMSSQLSERVER2;Initial Catalog=TDC;Integrated Security=True");
        
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        
        protected void Login1_Authenticate1(object sender, AuthenticateEventArgs e)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("select COUNT(*)FROM UserLogin WHERE UserName='" + Login1.UserName + "' and Password='" + Login1.Password + "'");
            cmd.Connection = con;
            int OBJ = Convert.ToInt32(cmd.ExecuteScalar());
            if (OBJ > 0)
            {
                //Response.Redirect("~/About.aspx");
                string name = Login1.UserName;

                Response.Redirect(string.Format("~/Admin.aspx?name={0}", name));
            }
            else
            {
                Response.Redirect("NotAuthorized.aspx");

            }
            //////string name = Login1.UserName;
            //////if (name =="sh")
            //////{
            //////    //Response.Redirect("Control.aspx");


            //////    Response.Redirect(string.Format("~/Account/NotAuthorized.aspx?name={0}", name));
            //////}
            //////else
            //////{
            //////    Response.Redirect("~/About.aspx");

        }
        }
    }
